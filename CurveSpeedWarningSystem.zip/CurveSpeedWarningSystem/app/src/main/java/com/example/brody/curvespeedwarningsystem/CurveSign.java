package com.example.brody.curvespeedwarningsystem;

import android.util.Log;

import com.google.android.gms.location.Geofence;

import java.io.Serializable;
import java.util.List;

/**
 * Created by surya on 3/31/16.
 */
public class CurveSign implements Serializable{
    public String id;
    public String highway;
    public String direction;
    public String signDescription;
    public String signSpeed;
    public String signLeg2;
    public String x;
    public String y;

    public CurveSign(){}

    public CurveSign(String id, String highway, String direction, String signDescription, String signSpeed,
                     String signLeg2, String x, String y) {
        this.id = id;
        this.highway = highway;
        this.direction = direction;
        this.signDescription = signDescription;
        this.signSpeed = signSpeed;
        this.signLeg2 = signLeg2;
        this.x = x;
        this.y = y;
    }

    public String getDirection(){
        return direction;
    }

    public static CurveSign getCurveSign(List<Geofence> listGeofence, List<CurveSign> listSigns) {
        for (Geofence geofence : listGeofence) {
            Log.e("geofence ids in list: ", geofence.getRequestId());
            for (CurveSign sign : listSigns) {
                Log.e("sign ids in list: ", sign.id);
                if (sign.id.equals(geofence.getRequestId())) {//) == geofence.getRequestId()) {
                    Log.e("return: ", sign.id);
                    return sign;
                }
            }
        }
        Log.e("return: ","null");
        return null;
    }

}
