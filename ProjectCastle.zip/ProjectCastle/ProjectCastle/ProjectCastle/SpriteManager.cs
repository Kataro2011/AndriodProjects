﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace ProjectCastle
{
    class SpriteManager : Microsoft.Xna.Framework.DrawableGameComponent
    {
        SpriteBatch spriteBatch;

        List<UserSprite> armyList = new List<UserSprite>();
        List<EnemySprite> enemyList = new List<EnemySprite>();

        public SpriteManager(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(Game.GraphicsDevice);

            //Load the player sprite
            armyList.Add(new Peasant(Game.Content.Load<Texture2D>(@"Images/Peasant"), 
                new Vector2(100, 0), new Point(24, 39), 10, new Point(0, 0), 
                new Point(1, 1), Vector2.One));

            armyList.Add(new Knight(Game.Content.Load<Texture2D>(@"Images/Knight"),
                new Vector2(100, 100), new Point(25, 39), 10, new Point(0, 0),
                new Point(1, 1), Vector2.One));

            armyList.Add(new Cavalry(Game.Content.Load<Texture2D>(@"Images/Cavalry"),
                new Vector2(100, 200), new Point(38, 39), 10, new Point(0, 0),
                new Point(1, 1), new Vector2(2, 2)));

            armyList.Add(new Archer(Game.Content.Load<Texture2D>(@"Images/Archer"),
                new Vector2(100, 300), new Point(33, 38), 10, new Point(0, 0),
                new Point(1, 1), Vector2.One));

            enemyList.Add(new Skeleton(Game.Content.Load<Texture2D>(@"Images/skeleton"),
                new Vector2(500, 300), new Point(24, 39), 10, new Point(0, 0),
                new Point(1, 1), new Vector2(1, 0)));
            
            base.LoadContent();
        }

        public bool Collide(UserSprite s, EnemySprite e)
        {
            return s.collisionRect.Intersects(e.collisionRect);
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            foreach (UserSprite s in armyList)
            {
                s.Update(gameTime, Game.Window.ClientBounds);
            }


            foreach (EnemySprite e in enemyList)
            {
                e.Update(gameTime, Game.Window.ClientBounds);
                    
            }

                base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend);

            foreach (UserSprite s in armyList)
                s.Draw(gameTime, spriteBatch);
            
            // Draw enemy sprites
            foreach (EnemySprite s in enemyList)
                s.Draw(gameTime, spriteBatch);
           
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
