﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ProjectCastle
{
    abstract class UserSprite : Sprite
    {

        MouseState prevMouseState;
        bool activeState;

        public override Vector2 direction
        {
            get
            {
               Vector2 inputDirection = Vector2.Zero;

               if (Keyboard.GetState().IsKeyDown(Keys.A))
                   inputDirection.X -= 1;
               if (Keyboard.GetState().IsKeyDown(Keys.D))
                   inputDirection.X += 1;
               if (Keyboard.GetState().IsKeyDown(Keys.W))
                   inputDirection.Y -= 1;
               if (Keyboard.GetState().IsKeyDown(Keys.S))
                   inputDirection.Y += 1;
                
                return inputDirection * speed;
            }
        }

        public UserSprite(Texture2D textureImage, Vector2 position,
            Point frameSize, int collisionOffset, Point currentFrame, Point sheetSize,
            Vector2 speed)
            : base(textureImage, position, frameSize, collisionOffset, currentFrame,
            sheetSize, speed)
        {
        }

        public override void Update(GameTime gameTime, Rectangle clientBounds)
        {
            if(checkState())
                position += direction;

            // If sprite is off the screen, move it back within the game window
            if (position.X < 0)
                position.X = 0;
            if (position.Y < 0)
                position.Y = 0;
            if (position.X > clientBounds.Width - frameSize.X)
                position.X = clientBounds.Width - frameSize.X;
            if (position.Y > clientBounds.Height - frameSize.Y)
                position.Y = clientBounds.Height - frameSize.Y;

            base.Update(gameTime, clientBounds);
        }

        public bool checkState()
        {
            MouseState ms = Mouse.GetState();

            Rectangle bounds = new Rectangle(Convert.ToInt32(position.X), Convert.ToInt32(position.Y), 24, 39);

            var mousePosition = new Point(ms.X, ms.Y);

            if (bounds.Contains(ms.X, ms.Y))
            {
                if (ms.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released)
                {
                    activeState = true;
                }
            }
            else
            {
                if (ms.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released)
                {
                    activeState = false;
                }
            }

            prevMouseState = ms;

            return activeState;
        }


    }
}
